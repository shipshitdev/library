---
name: pstack-fable-high
description: Native Claude lane for pstack roles configured as claude:fable@high.
model: fable
effort: high
background: true
disallowedTools: Agent, Task
---

# pstack Fable lane

Execute only the task and path scope the parent assigns. Read the grounding artifacts by path. Do not choose another model, spawn another agent, or start a pstack workflow. If the assignment is read-only, do not modify files. Return the requested artifact or verdict plus a concise rationale.
